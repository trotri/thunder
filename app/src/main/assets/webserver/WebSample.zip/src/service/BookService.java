package service;

import db.BookDb;
import entity.BookEntity;
import entity.ErrorMsg;
import entity.ErrorNo;
import entity.ResponseAdapter;

/**
 * BookService class file
 *
 * @author 宋欢 <trotri@yeah.net>
 * @version $Id: BookService.java 1 2016-11-07 10:00:06Z huan.song $
 * @since 1.0
 */
public class BookService {
	/**
	 * DB类
	 */
	private BookDb mDb = new BookDb();

	/**
	 * 获取列表
	 *
	 * @param offset
	 *            查询起始位置 SELECT * FROM table LIMIT [offset], limit;
	 * @param limit
	 *            查询记录数 SELECT * FROM table LIMIT offset, [limit];
	 * @return 列表，a ResponseAdapter.ResultList<BookEntity>
	 */
	public ResponseAdapter.ResultList<BookEntity> findRows(int offset, int limit) {
		ResponseAdapter.ResultList<BookEntity> result = new ResponseAdapter.ResultList<BookEntity>();

		if (limit == 8 && offset > 16) {
			result.setErrNo(ErrorNo.ERROR_RESULT_EMPTY);
			result.setErrMsg(ErrorMsg.ERROR_RESULT_EMPTY);
			return result;
		}

		if (limit != 8 || (offset != 0 && offset != 8 && offset != 16)) {
			result.setErrNo(ErrorNo.ERROR_ARGS_ERR);
			result.setErrMsg(ErrorMsg.ERROR_ARGS_ERR);
			return result;
		}

		ResponseAdapter.DataList<BookEntity> data = new ResponseAdapter.DataList<BookEntity>();
		data.setOffset(offset);
		data.setLimit(limit);
		data.setTotal(mDb.getTotal());
		data.setRows(mDb.findRows(offset, limit));

		result.setData(data);
		return result;
	}

	/**
	 * 通过id获取详情
	 *
	 * @param id
	 *            ID
	 * @return 详情，a ResponseAdapter.Result<BookEntity>
	 */
	public ResponseAdapter.Result<BookEntity> getRow(long id) {
		ResponseAdapter.Result<BookEntity> result = new ResponseAdapter.Result<BookEntity>();

		if (id < 1) {
			result.setErrNo(ErrorNo.ERROR_ARGS_ERR);
			result.setErrMsg(ErrorMsg.ERROR_ARGS_ERR);
			return result;
		}

		BookEntity data = mDb.getRow(id);
		if (data == null) {
			result.setErrNo(ErrorNo.ERROR_RESULT_EMPTY);
			result.setErrMsg(ErrorMsg.ERROR_RESULT_EMPTY);
			return result;
		}

		result.setData(data);
		return result;
	}

}
