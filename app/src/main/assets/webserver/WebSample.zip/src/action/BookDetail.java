package action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.BookEntity;
import entity.ResponseAdapter;
import helper.GsonHelper;
import helper.Util;
import service.BookService;

/**
 * Servlet implementation class BookDetail
 */
@WebServlet(description = "BookDetail", urlPatterns = { "/book_detail" })
public class BookDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * 业务类
	 */
	private BookService mService;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BookDetail() {
		super();

		mService = new BookService();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		long id = Util.str2Long(request.getParameter("id"));

		ResponseAdapter.Result<BookEntity> result = mService.getRow(id);

		response.setCharacterEncoding("UTF-8");
		response.getWriter().print(GsonHelper.create().toJson(result));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
