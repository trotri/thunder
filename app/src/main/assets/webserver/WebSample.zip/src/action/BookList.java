package action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.BookEntity;
import entity.ResponseAdapter;
import helper.GsonHelper;
import helper.Util;
import service.BookService;

/**
 * Servlet implementation class BookList
 */
@WebServlet(description = "BookList", urlPatterns = { "/book_list" })
public class BookList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * 业务类
	 */
	private BookService mService;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BookList() {
		super();

		mService = new BookService();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int offset = Util.str2Int(request.getParameter("offset"));
		int limit = Util.str2Int(request.getParameter("limit"));

		ResponseAdapter.ResultList<BookEntity> result = mService.findRows(offset, limit);

		response.setCharacterEncoding("UTF-8");
		response.getWriter().print(GsonHelper.create().toJson(result));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
