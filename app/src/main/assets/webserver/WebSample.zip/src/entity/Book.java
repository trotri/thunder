package entity;

public class Book {
	private int id;
	private String title;
	private float price;
	
	public int getId() {
		return id;
	}
	
	public Book setId(int id) {
		this.id = id;
		return this;
	}
	
	public String getTitle() {
		return title;
	}
	
	public Book setTitle(String title) {
		this.title = title;
		return this;
	}
	
	public float getPrice() {
		return price;
	}
	
	public Book setPrice(float price) {
		this.price = price;
		return this;
	}

	public class Inner {
		public void run() {
			Book book = new Book();
			book.setId(10).setTitle("Java编程思想").setPrice(10.44f);
		}
	}
}
