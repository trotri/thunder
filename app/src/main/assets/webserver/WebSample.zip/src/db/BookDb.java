package db;

import java.util.ArrayList;
import java.util.List;

import entity.BookEntity;

/**
 * BookDb class file
 *
 * @author 宋欢 <trotri@yeah.net>
 * @version $Id: BookDb.java 1 2016-11-07 10:00:06Z huan.song $
 * @since 1.0
 */
public class BookDb {
	/**
	 * 获取列表
	 *
	 * @param offset
	 *            查询起始位置 SELECT * FROM table LIMIT [offset], limit;
	 * @param limit
	 *            查询记录数 SELECT * FROM table LIMIT offset, [limit];
	 * @return 列表，a List, or null
	 */
	public List<BookEntity> findRows(int offset, int limit) {
		switch (offset) {
		case 0:
			return mock_0_8();
		case 8:
			return mock_8_8();
		case 16:
			return mock_16_8();
		}

		return null;
	}

	/**
	 * 通过id获取详情
	 *
	 * @param id
	 *            ID
	 * @return 详情，a BookEntity, or null
	 */
	public BookEntity getRow(long id) {
		List<BookEntity> rows = findAll();

		for (BookEntity row : rows) {
			if (row.getId() == id) {
				return row;
			}
		}

		return null;
	}

	/**
	 * 获取总记录数
	 *
	 * @return 总记录数
	 */
	public long getTotal() {
		return findAll().size();
	}

	/**
	 * 获取全部数据
	 *
	 * @return 全部数据列表
	 */
	public List<BookEntity> findAll() {
		List<BookEntity> result = new ArrayList<BookEntity>();

		result.addAll(mock_0_8());
		result.addAll(mock_8_8());
		result.addAll(mock_16_8());

		return result;
	}

	/**
	 * 模拟数据，offset = 0, limit = 8
	 *
	 * @return 列表
	 */
	private List<BookEntity> mock_0_8() {
		List<BookEntity> result = new ArrayList<BookEntity>();

		result.add(new BookEntity(1, "Java编程思想", "编程语言", "C++、Java中的圣经级著作",
				"http://img14.360buyimg.com/n1/jfs/t2191/111/699154754/198998/32d7bfe0/5624b582Nbc01af5b.jpg", false,
				"00-00 00:01"));
		result.add(new BookEntity(2, "C++编程思想", "编程语言", "1994年度JOLT大奖获奖图书荣获第6届Jolt生产效率大奖获奖图书",
				"http://img14.360buyimg.com/n1/18448/80f61267-950f-4654-b34a-529add85c898.jpg", false, "00-00 00:02"));
		result.add(new BookEntity(3, "高性能MySQL", "数据库", "2013年排名前十的技术影响力引进图书之一",
				"http://img13.360buyimg.com/n1/g10/M00/17/1C/rBEQWFF00eMIAAAAAADX132P3PkAAEqmABYSIQAANfv613.jpg", false,
				"00-00 00:03"));
		result.add(new BookEntity(4, "深入浅出MySQL", "数据库",
				"MySQL原创图书之一，网易技术部DBA组时隔5年再献力作，把MySQL用到高境界的实践，高性能mysql指导指南，mysql数据库必备宝典！",
				"http://img10.360buyimg.com/n1/g13/M01/11/06/rBEhU1LQxrAIAAAAAAKmO7XSO1AAAH0uQBQfwoAAqZT742.jpg", false,
				"00-00 00:04"));
		result.add(new BookEntity(5, "MySQL必知必会", "数据库", "紧贴实战需要，适用于广大软件开发和数据库管理人员学习参考",
				"http://img13.360buyimg.com/n1/jfs/t2593/48/3523110588/234188/577f99d9/5791b08fN4ebfbc11.png", false,
				"00-00 00:05"));
		result.add(new BookEntity(6, "SQL解惑", "数据库", "75个妙趣横生的SQL谜题",
				"http://img11.360buyimg.com/n1/13432/1b9b929e-959f-4b1a-8902-41ca33eac7c2.jpg", true, "00-00 00:06"));
		result.add(new BookEntity(7, "密码编码与信息安全", "编程算法", "讨论密码编码学与信息安全的基本原理，并以基本原理为基础，重在探讨C++的实现方法",
				"http://img13.360buyimg.com/n1/jfs/t1582/250/1010212162/143094/e5722c42/55b82ef1N4375ed30.jpg", false,
				"00-00 00:07"));
		result.add(new BookEntity(8, "数据结构与算法分析", "编程算法", "",
				"http://img14.360buyimg.com/n1/jfs/t2464/214/2764818483/66820/e6d31dfc/56ef155aN993b4639.jpg", false,
				"00-00 00:08"));

		return result;
	}

	/**
	 * 模拟数据，offset = 8, limit = 8
	 *
	 * @return 列表
	 */
	private List<BookEntity> mock_8_8() {
		List<BookEntity> result = new ArrayList<BookEntity>();

		result.add(new BookEntity(9, "从你的全世界路过", "小说", "那么多睡前故事，有温暖的，有明亮的，有落单的，有疯狂的",
				"http://img11.360buyimg.com/n1/jfs/t3301/242/2672651894/198171/c5450dbe/57e4c0d1Nb5c76369.jpg", false,
				"00-00 00:11"));
		result.add(new BookEntity(10, "解忧杂货店", "小说", "僻静的街道旁有一家杂货店，只要写下烦恼投进店前门卷帘门的投信口，第二天就会在店后的牛奶箱里得到回答。",
				"http://img10.360buyimg.com/n1/g13/M04/09/0E/rBEhU1Nd33IIAAAAAAFbHX75EAsAAMjgAMdgs0AAVs1993.jpg", false,
				"00-00 00:12"));
		result.add(
				new BookEntity(11, "我们仨", "小说", "一百零五岁的杨绛，以简洁而沉重的语言，回忆了女儿钱瑗、丈夫钱钟书，一家三口那些快乐而艰难、爱与痛的日子。故事证明：家庭是人生的庇护所。",
						"http://img14.360buyimg.com/n1/jfs/t1543/143/360365215/354050/8ee304f5/5577dd14N1e66fcf6.jpg",
						true, "00-00 00:13"));
		result.add(new BookEntity(12, "平凡的世界", "小说", "茅盾文学奖皇冠上的明珠，激励千万青年的不朽经典，深受老师和学生喜爱的新课标必读书。",
				"http://img11.360buyimg.com/n1/jfs/t2776/103/2377132330/253920/5548d752/57624115Nc275397b.jpg", true,
				"00-00 00:14"));
		result.add(new BookEntity(13, "围城", "小说", "三十年来横贯常销畅销小说之首",
				"http://img12.360buyimg.com/n1/g15/M07/01/01/rBEhWVG5n3IIAAAAAAsWUKFtxGsAAANCwG0u7cACxZo396.jpg", false,
				"00-00 00:15"));
		result.add(new BookEntity(14, "三体", "小说", "中国科幻大师巨作 万千科幻迷翘首以待，获2015科幻文坛荣誉“雨果奖”",
				"http://img11.360buyimg.com/n1/g13/M00/0F/1A/rBEhVFJWgtQIAAAAABYy8ainCvkAAD_CwIhjcQAFjMJ922.jpg", false,
				"00-00 00:16"));
		result.add(new BookEntity(15, "不忘初心，方得始终", "小说", "一本优雅的散文：改变亿万人为人处世方式的优雅的散文。",
				"http://img11.360buyimg.com/n1/g13/M05/00/1B/rBEhUlHjTCIIAAAAAA1IzrY0y2kAABD8gDYIekADUjm834.jpg", false,
				"00-00 00:17"));
		result.add(new BookEntity(16, "一个人的朝圣", "小说", "2013年欧洲首席畅销小说",
				"http://img12.360buyimg.com/n1/g15/M04/03/16/rBEhWlIDZHEIAAAAAAgV6bD1JTcAAB26gAaWVwACBYB478.jpg", false,
				"00-00 00:18"));

		return result;
	}

	/**
	 * 模拟数据，offset = 16, limit = 8
	 *
	 * @return 列表
	 */
	private List<BookEntity> mock_16_8() {
		List<BookEntity> result = new ArrayList<BookEntity>();

		result.add(new BookEntity(17, "边城", "小说", "琉璃般透明的世界，守护着人性中的至真、至善与至美。",
				"http://img11.360buyimg.com/n1/jfs/t1261/300/1301429691/349193/1d932873/558b9b17N2f9ac984.jpg", false,
				"00-00 00:21"));
		result.add(new BookEntity(18, "幻城", "小说", "开启冰火世界的奇幻境域。",
				"http://img12.360buyimg.com/n1/jfs/t2659/227/863250620/305040/cb07eb53/5729a117N2a524ad2.jpg", false,
				"00-00 00:22"));
		result.add(new BookEntity(19, "斯坦福极简经济学", "经史", "如何果断地权衡利益得失",
				"http://img10.360buyimg.com/n1/jfs/t751/49/545293657/159542/3ac03eca/54bcd7c0Na59ce3bf.jpg", false,
				"00-00 00:23"));
		result.add(new BookEntity(20, "人类简史 从动物到上帝", "经史", "理清影响人类发展的重大脉络，解除历史的枷锁，看到多种多样的未来。",
				"http://img10.360buyimg.com/n1/jfs/t1633/284/1427773805/57779/d00500e/572d5ef0N82c9dc8c.jpg", false,
				"00-00 00:24"));
		result.add(new BookEntity(21, "中国哲学简史", "经史",
				"韩国女总统朴槿惠艰难的平衡，“萨德”入韩，不会影响G20构建创新、活力、联动、包容的4I世界！中国著名哲学家冯友兰圣人的睿智，《中国哲学简史》，值得各阶层读者读上千遍!",
				"http://img10.360buyimg.com/n1/g10/M00/09/1A/rBEQWVE-iPYIAAAAAAWSfpY8wXAAAB7BgOGkB8ABZKW158.jpg", false,
				"00-00 00:25"));
		result.add(new BookEntity(22, "魔鬼经济学", "经史", "江湖奇书，洞察人心深层动机，聪明人怎样看世界！",
				"http://img11.360buyimg.com/n1/jfs/t2926/111/2682732762/463247/468549ba/57ba9e6bN6b2da065.jpg", false,
				"00-00 00:26"));
		result.add(new BookEntity(23, "激荡三十年", "经史", "吴晓波经典作品，不可错过的中国当代史",
				"http://img13.360buyimg.com/n1/jfs/t163/271/3154774663/343936/2234ca66/53e20697Nc5cb2e42.jpg", true,
				"00-00 00:27"));
		result.add(new BookEntity(24, "大败局", "经史", "财经作家吴晓波经典之作，影响中国商业界的二十本图书”之一，关于中国企业失败的MBA式教案",
				"http://img12.360buyimg.com/n1/jfs/t1312/70/442726711/393930/120bf7fc/55767773N1a334e7a.jpg", false,
				"00-00 00:28"));

		return result;
	}

}
