package helper;

/**
 * Util class file
 *
 * @author 宋欢 <trotri@yeah.net>
 * @version $Id: Utils.java 1 2016-10-24 10:00:06Z huan.song $
 * @since 1.0
 */
public class Util {
	/**
	 * 字符串转整型
	 * 
	 * @param value
	 *            字符串
	 * @return 整型，如果转换失败，返回：0
	 */
	public static int str2Int(String value) {
		try {
			return Integer.valueOf(value);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}

		return 0;
	}

	/**
	 * 字符串转长整型
	 * 
	 * @param value
	 *            字符串
	 * @return 长整型，如果转换失败，返回：0
	 */
	public static long str2Long(String value) {
		try {
			return Long.valueOf(value);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}

		return 0;
	}

}
