package helper;

import com.google.gson.FieldNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Field;

/**
 * GsonHelper class file Gson辅助类
 *
 * @author 宋欢 <trotri@yeah.net>
 * @version $Id: GsonHelper.java 1 2015-10-16 15:01:06Z huan.song $
 * @since 1.0
 */
public class GsonHelper {
	/**
	 * 属性名前缀
	 */
	public static final String FIELD_NAME_PREFIX = "m";

	/**
	 * Gson属性名处理器
	 */
	public static FieldNamingStrategy sFieldNameStrategy = new FieldNamingStrategy() {
		@Override
		public String translateName(Field f) {
			String fieldName = f.getName();
			return removeFieldNamePrefix(fieldName);
		}
	};

	/**
	 * a Gson object
	 */
	private static Gson sGson;

	/**
	 * Create the {@link Gson} instance.
	 *
	 * @return a Gson object
	 */
	public static Gson create() {
		if (sGson == null) {
			sGson = (new GsonBuilder()).setFieldNamingStrategy(sFieldNameStrategy).create();
		}

		return sGson;
	}

	/**
	 * 删除属性名前缀，前缀：m
	 *
	 * @param fieldName
	 *            原始属性名
	 * @return 删除前缀的属性名
	 */
	public static String removeFieldNamePrefix(String fieldName) {
		if (fieldName != null && fieldName.startsWith(FIELD_NAME_PREFIX) && fieldName.length() > 1) {
			fieldName = fieldName.substring(1);
			fieldName = firstToLowerCase(fieldName);
		}

		return fieldName;
	}

	/**
	 * 将字符串首字母小写
	 *
	 * @param s
	 *            原始字符串
	 * @return 首字母小写字符串
	 */
	public static String firstToLowerCase(String s) {
		if (s != null && s.length() > 0) {
			s = s.substring(0, 1).toLowerCase() + s.substring(1);
		}

		return s;
	}

}
